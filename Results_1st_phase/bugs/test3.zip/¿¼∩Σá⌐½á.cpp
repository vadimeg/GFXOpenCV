#include <gfx/gfx_rt.h>
#include <cilk/cilk.h>

__declspec(target(gfx_kernel))
void test(int *a, int *b, int len_a, int len_b) {
    cilk_for(int i = 0; i < len_a; i++) {
        cilk_for(int j = 0; j < len_b; j++) {
            *b = *a + j * i;
        }
    }
}

int main() {
    int *a = new int[1000];
    int *b = new int[2000];
    _GFX_share((void*)a, 1000);
    _GFX_share((void*)b, 1000);

    _GFX_offload(test, a, b, 1000, 2000);
    _GFX_wait();
    _GFX_unshare(a);
    _GFX_unshare(b);

    return 0;
}
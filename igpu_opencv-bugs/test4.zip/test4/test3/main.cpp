#include <gfx/gfx_rt.h>
#include <cilk/cilk.h>

__declspec(target(gfx_kernel))
void gfxKernel(int* dstptr, int param) {

    cilk_for (int y = 0; y <= 0; y++)
        cilk_for (int x = 0; x <= 0; x++) {
            int cachedColRes[1];
            const int stride = 3;
            *dstptr = __sec_reduce_add(cachedColRes[0 : param : stride]);
        }
}

int main(int argc, char** argv) {
    return 0;
}

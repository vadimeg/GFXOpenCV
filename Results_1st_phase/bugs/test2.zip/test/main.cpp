#include <gfx/gfx_rt.h>
#include <cilk/cilk.h>

#include <iostream>

using std::cout;
using std::endl;
using uchar = unsigned char;
using uint = unsigned int;

#define loadSrc_direct_greedy(x, y, value)                                                         \
        value = *(T*)(&srcptr[(((y) + dstOffsetY) * srcStep + (x) + dstOffsetX) * depth])

#define storeDst_direct(x, y, value)                                                               \
        if (depth == sizeof(T))                                                                \
            *(T*)(&dstptr[(((y) + dstOffsetY) * dstStep + (x) + dstOffsetX) * depth]) = value;                 \
        else                                                                                   \
            for (int c = 0; c < depth; c++)                                                    \
                dstptr[(((y) + dstOffsetY) * dstStep + (x) + dstOffsetX) * depth + c] = ((uchar*)&value)[c]

#define medianFilter_atPixel(x, y, loadSrc, storeDst) {                                                 \
    T p[3 * 3];                                                                            \
    loadSrc(x - 1, y - 1, p[0]);                                                                              \
    loadSrc(x, y - 1, p[1]);                                                                                     \
    loadSrc(x + 1, y - 1, p[2]);                                                                                 \
    loadSrc(x - 1, y, p[3]);                                                                                     \
    loadSrc(x, y, p[4]);                                                                                         \
    loadSrc(x + 1, y, p[5]);                                                                                     \
    loadSrc(x - 1, y + 1, p[6]);                                                                                 \
    loadSrc(x, y + 1, p[7]);                                                                                     \
    loadSrc(x + 1, y + 1, p[8]);                                                                                 \
                                                                                                                 \
    storeDst(x, y, p[(3 * 3) / 2]);                                                                                 \
}


template< typename T, int pixelSize, int srcOffsetY, int srcOffsetX, int dstOffsetX, int dstOffsetY >
__declspec(target(gfx_kernel))
void medianFilter_atCenter(const uchar* restrict srcptr, uchar* restrict dstptr, int rowsMinusBorder, int colsMinusBorder) {
    cilk_for(int y = 3 / 2; y < rowsMinusBorder; y++)
#pragma simd
        cilk_for(int x = 3 / 2; x < colsMinusBorder; x++) {
            const int borderWidth = 3 / 2;
            const int depth = pixelSize;
            const int srcStep = colsMinusBorder + borderWidth;
            const int dstStep = colsMinusBorder + borderWidth;
            medianFilter_atPixel(x, y, loadSrc_direct_greedy, storeDst_direct);
        }
}



const int cn = 3;
const int IMG_SIZE_X = 100 * cn;
const int IMG_SIZE_Y = 100 * cn;
int main(int argc, char** argv)
{
	int w = IMG_SIZE_X;
	int h = IMG_SIZE_Y;
	uchar* src_offloaded = (uchar*)malloc(w * h);
	uchar* dst_offloaded = (uchar*)malloc(w * h);
	uchar* src_host = (uchar*)malloc(w * h);
	uchar* dst_host = (uchar*)malloc(w * h);

    for (int i = 0; i < w * h; i++)
        src_offloaded[i] = src_host[i] = (uchar)i; //src_offloaded[] == src_host[]

	medianFilter_atCenter<uint, cn, 0, 0, 0, 0>(src_host, dst_host, h / cn - 3 / 2, w / cn - 3 / 2);

	_GFX_share(src_offloaded, h * w);
	_GFX_share(dst_offloaded, h * w);
    
    _GFX_offload(&medianFilter_atCenter<uint, cn, 0, 0, 0, 0>, src_offloaded, dst_offloaded, h / cn - 3 / 2, w / cn - 3 / 2);
	_GFX_wait();

	_GFX_unshare(src_offloaded);
	_GFX_unshare(dst_offloaded);

    for (int x = 1; x < w - 1; x++)
        for (int y = 1; y < h - 1; y++)
            if (dst_offloaded[y * w + x] != dst_host[y * w + x])
                cout << "dst_offloaded[" << y << "][" << x << "] != dst_host[" << y << "][" << x << "]" << endl; //src_offloaded[] != src_host[]

	return 0;
}
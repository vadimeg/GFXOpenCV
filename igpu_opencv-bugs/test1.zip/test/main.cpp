#include <gfx/gfx_rt.h>
#include <cilk/cilk.h>

#include <iostream>

using std::cout;
using std::endl;
using uchar = unsigned char;
using uint = unsigned int;

template< typename T, int pixelSize, int srcOffsetY, int srcOffsetX, int dstOffsetX, int dstOffsetY >
__declspec(target(gfx_kernel))
void medianFilter_atCenter(const uchar* restrict srcptr, uchar* restrict dstptr, int rowsMinusBorder, int colsMinusBorder) {
    cilk_for(int y = 3 / 2; y < rowsMinusBorder; y++)
        cilk_for(int x = 3 / 2; x < colsMinusBorder; x++) {
        }
}



const int cn = 3;
const int IMG_SIZE_X = 100 * cn;
const int IMG_SIZE_Y = 100 * cn;
int main(int argc, char** argv)
{
	int w = IMG_SIZE_X;
	int h = IMG_SIZE_Y;
	uchar* src_offloaded = (uchar*)malloc(w * h);
	uchar* dst_offloaded = (uchar*)malloc(w * h);

	_GFX_share(src_offloaded, h * w);
	_GFX_share(dst_offloaded, h * w);
    
    _GFX_offload(&medianFilter_atCenter<int, cn, 0, 0, 0, 0>, src_offloaded, dst_offloaded, h / cn - 3 / 2, w / cn - 3 / 2);
    _GFX_offload(&medianFilter_atCenter<uint, cn, 0, 0, 0, 0>, src_offloaded, dst_offloaded, h / cn - 3 / 2, w / cn - 3 / 2);
	_GFX_wait();

	_GFX_unshare(src_offloaded);
	_GFX_unshare(dst_offloaded);

    free(src_offloaded);
    free(dst_offloaded);

    cout << "Passed" << endl;

	return 0;
}